// $Id: fillfnam.h 4102 2006-12-08 09:43:35Z jj $
//
// $Log$

#ifndef __FILLFNAM_H__
#define __FILLFNAM_H__

int tab_pressed(char *cmdlinefull, int *cmdoffset);

#endif
