/* BUILD_PCH  (c)Copyright Ivan Warren, 2005-2009                    */
/*            Dummy module for building pre-compiled header files    */

// $Id: build_pch.c 5125 2009-01-23 12:01:44Z bernard $
//
// $Log$
// Revision 1.5  2007/06/23 00:04:03  ivan
// Update copyright notices to include current year (2007)
//
// Revision 1.4  2006/12/08 09:43:16  jj
// Add CVS message log
//

#include "hstdinc.h"
